package com.example.liste_meme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerTitleStrip;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    String [] memeTiteles;
    String [] memedes;
    int [] images = {R.drawable.mem1,R.drawable.mem2,R.drawable.mem3,R.drawable.mem4,R.drawable.mem5,R.drawable.mem6,R.drawable.mem7,R.drawable.mem8,R.drawable.mem9};
    private ListView Liste ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Resources res = getResources();

        memeTiteles = res.getStringArray(R.array.Titles);
        memedes = res.getStringArray(R.array.des);
        Liste = findViewById(R.id.View);
        Adape Adapter = new Adape(this,memeTiteles,images,memedes);
        Liste.setAdapter(Adapter);

    }
}
class Adape  extends ArrayAdapter<String>   {
Context context;
int images [];
String Titless [];
String dess [];
Adape (Context C , String []  Titles,int img [], String des []) {
    super(C,R.layout.draw,R.id.Te1, Titles);
    this.context=C;
    this.images=img;
    this.Titless=Titles;
    this.dess=des;
}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
       View row= inflater.inflate(R.layout.draw,parent,false);
       ImageView MyImage= row.findViewById(R.id.View);
       TextView MyTitle = row.findViewById(R.id.Te1);
       TextView MyDes = row.findViewById(R.id.Te2);
       MyImage.setImageResource(images[position]);
       MyTitle.setText(Titless[position]);
       MyDes.setText(dess[position]);
        return  row;
    }
}