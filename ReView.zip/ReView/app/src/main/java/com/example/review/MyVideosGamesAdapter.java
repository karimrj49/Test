package com.example.review;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyVideosGamesAdapter extends RecyclerView.Adapter<MyVideosGamesAdapter.MyViewHolder> {
     List<Games> game ;

    public MyVideosGamesAdapter(List<Games> game) {
        this.game = game;
    }

    @NonNull
    @Override
    public MyVideosGamesAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view =inflater.inflate(R.layout.draw,parent,false);


        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyVideosGamesAdapter.MyViewHolder holder, int position) {
holder.Display(game.get(position));
    }

    @Override
    public int getItemCount() {
        return game.size();
    }


    public class MyViewHolder  extends RecyclerView.ViewHolder {


private TextView nName;
private TextView mPrice;

    public MyViewHolder( View itemView) {
        super(itemView);
        nName = (TextView) itemView.findViewById(R.id.te1);
        mPrice = (TextView) itemView.findViewById(R.id.te2);
    }
    void Display (Games jeuVideo) {

        nName.setText(jeuVideo.getName());
        mPrice.setText( jeuVideo.getPrice()+ "E");

    }
} }

