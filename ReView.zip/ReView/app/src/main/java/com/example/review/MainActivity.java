package com.example.review;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
private RecyclerView re1;
private List<Games> game;
private MyVideosGamesAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        re1 = (RecyclerView) findViewById(R.id.re1);
        game  = new ArrayList<>();
        game.add(new Games("Forza 3",49.09F));
        game.add(new Games("Fifa 20",60.99F));
        game.add(new Games("Gta 5",30.00F));
        game.add(new Games("Res 7",80.89F));
        adapter = new MyVideosGamesAdapter(game);
        re1.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        re1.setAdapter(adapter);
    }
}
